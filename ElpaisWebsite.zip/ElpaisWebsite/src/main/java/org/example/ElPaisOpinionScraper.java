package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.HashMap;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.json.JSONObject;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ElPaisOpinionScraper {
    private static final String BASE_URL = "https://elpais.com";
    private static final String IMAGE_DOWNLOAD_PATH = "article_images/";

    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--lang=es");
        options.addArguments("--disable-notifications");
        options.addArguments("--start-maximized");

        WebDriver driver = DriverFactory.getDriver(options);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        // Create image download directory
        createImageDirectory();

        try {
            driver.get(BASE_URL);
            handleCookieConsent(driver, wait);
            navigateToOpinionSection(driver, wait);

            List<ArticleInfo> articlesToProcess = new ArrayList<>();
            Map<String, Integer> wordCountMap = new HashMap<>();

            By articleHeadlineSelector = By.cssSelector("article h2 a");
            List<WebElement> articleHeadlines = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(articleHeadlineSelector));
            System.out.println("Found " + articleHeadlines.size() + " article headlines in the 'Opinión' section.");

            for (int i = 0; i < articleHeadlines.size() && articlesToProcess.size() < 5; i++) {
                if (i != 4) {
                    WebElement article = articleHeadlines.get(i);
                    articlesToProcess.add(new ArticleInfo(
                            article.getAttribute("href"),
                            article.getText()
                    ));
                }
            }
            for (ArticleInfo article : articlesToProcess) {
                try {
                    System.out.println("\nProcessing Article: " + article.title());
                    System.out.println("URL: " + article.url());

                    // Translate article title
                    String translatedTitle = translateText(article.title());
                    System.out.println("Translated Title: " + translatedTitle);

                    // Update word count map
                    updateWordCountMap(translatedTitle, wordCountMap);

                    driver.get(article.url());

                    // Get article content
                    String content = getArticleContent(driver, wait, article.title());
                    System.out.println("Content:\n" + content);

                    // Download cover image if available
                    downloadCoverImage(driver, wait, translatedTitle);

                    navigateToOpinionSection(driver, wait);

                } catch (Exception e) {
                    System.out.println("Error processing article: " + article.title());
                    e.printStackTrace();
                }
            }

            // Print repeated words and their counts
            printRepeatedWords(wordCountMap);

        } catch (Exception e) {
            System.out.println("Error in main process: " + e.getMessage());
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }

    private static void createImageDirectory() {
        try {
            Files.createDirectories(Paths.get(IMAGE_DOWNLOAD_PATH));
            System.out.println("Image directory created successfully");
        } catch (IOException e) {
            System.out.println("Error creating image directory: " + e.getMessage());
        }
    }

    private static void downloadCoverImage(WebDriver driver, WebDriverWait wait, String articleTitle) {
        try {
            // Wait for the cover image to be present
            By coverImageSelector = By.cssSelector("img[class*='_re  a_m-h']");
            WebElement imageElement = wait.until(ExpectedConditions.presenceOfElementLocated(coverImageSelector));

            // Get the image URL
            String imageUrl = imageElement.getAttribute("src");
            if (imageUrl != null && !imageUrl.isEmpty()) {
                // Create a safe filename from the article title
                String safeFileName = articleTitle.replaceAll("[^a-zA-Z0-9]", "_") + ".jpg";
                String imagePath = IMAGE_DOWNLOAD_PATH + safeFileName;

                // Download the image
                try (InputStream in = new URL(imageUrl).openStream()) {
                    Files.copy(in, Paths.get(imagePath), StandardCopyOption.REPLACE_EXISTING);
                    System.out.println("Cover image downloaded successfully: " + safeFileName);
                }
            } else {
                System.out.println("No cover image found for article: " + articleTitle);
            }
        } catch (Exception e) {
            System.out.println("Error downloading cover image for article '" + articleTitle + "': " + e.getMessage());
        }
    }

    private static void handleCookieConsent(WebDriver driver, WebDriverWait wait) {
        try {
            By cookieAcceptButton = By.cssSelector("button#didomi-notice-agree-button.didomi-components-button");
            wait.until(ExpectedConditions.presenceOfElementLocated(cookieAcceptButton));
            WebElement acceptButton = wait.until(ExpectedConditions.elementToBeClickable(cookieAcceptButton));
            if (acceptButton != null) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", acceptButton);
                System.out.println("Cookie accept button clicked successfully");
            }
        } catch (Exception e) {
            System.out.println("Error handling cookie consent: " + e.getMessage());
        }
    }

    private static void navigateToOpinionSection(WebDriver driver, WebDriverWait wait) {
        driver.get("https://elpais.com/opinion/");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("article h2 a")));
        System.out.println("Navigated to 'Opinión' section.");
    }

    private static String getArticleContent(WebDriver driver, WebDriverWait wait, String articleTitle) {
        try {
            for (int attempt = 1; attempt <= 3; attempt++) {
                try {
                    By articleContentSelector = By.cssSelector("div.a_c");
                    WebElement contentElement = wait.until(ExpectedConditions.presenceOfElementLocated(articleContentSelector));
                    return contentElement.getText();
                } catch (Exception e) {
                    if (attempt == 3) throw e;
                    System.out.println("Attempt " + attempt + " failed, retrying...");
                    Thread.sleep(1000);
                }
            }
        } catch (Exception e) {
            System.out.println("Unable to fetch content for '" + articleTitle + "': " + e.getMessage());
        }
        return "Content not available";
    }

    private static String translateText(String text) {
        try {
            HttpClient client = HttpClient.newHttpClient();

            // Create JSON body with correct language codes
            JSONObject body = new JSONObject();
            body.put("from", "es");    // Spanish (source language)
            body.put("to", "en");      // English (target language)
            body.put("html", text);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://google-translate113.p.rapidapi.com/api/v1/translator/html"))
                    .header("content-type", "application/json")
                    .header("X-RapidAPI-Key", "4d075840aemsh6cb06099e994ae3p1c9344jsnc56425a26f87")
                    .header("X-RapidAPI-Host", "google-translate113.p.rapidapi.com")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                JSONObject jsonResponse = new JSONObject(response.body());
                String translatedText = jsonResponse.getString("trans");
                return translatedText;
            } else {
                System.out.println("Translation API call failed with status code: " + response.statusCode());
                System.out.println("Response body: " + response.body());
            }
        } catch (Exception e) {
            System.out.println("Error during translation: " + e.getMessage());
            e.printStackTrace();
        }
        return text; // Fallback to original text if translation fails
    }

    private static void updateWordCountMap(String title, Map<String, Integer> wordCountMap) {
        String[] words = title.split("\\s+");
        for (String word : words) {
            word = word.replaceAll("[^a-zA-Z]", "").toLowerCase(); // Remove non-alphabetic characters and convert to lowercase
            if (!word.isEmpty()) {
                wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
            }
        }
    }

    private static void printRepeatedWords(Map<String, Integer> wordCountMap) {
        System.out.println("\nRepeated words and their counts:");
        for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
            if (entry.getValue() > 2) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
    }
}

record ArticleInfo(String url, String title) {}


