package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.time.Duration;

public class DriverFactory {
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static WebDriver getDriver(ChromeOptions options) {
        if (driver.get() == null) {
            String browser = ("chrome");
            switch (browser.toLowerCase()) {
                case "chrome":
                    WebDriverManager.chromedriver().setup();
                    if (options == null) {
                        options = new ChromeOptions();
                        options.addArguments("--disable-notifications");
                        options.addArguments("--start-maximized");
                        options.setPageLoadTimeout(Duration.ofSeconds(15));
                    }
                    driver.set(new ChromeDriver(options));
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    driver.set(new FirefoxDriver());
                    break;
                default:
                    throw new RuntimeException("Unsupported browser: " + browser);
            }
        }
        return driver.get();
    }

    public static WebDriver getDriver() {
        return getDriver(null);
    }
}